# Montaje del documental de Carlos Kaiser

## Resultado

`Kaiser_documental_final.mp4`: 1920 × 1080, 30 fps, H.264, yuv420p,
rango de video limitado BT.709, audio AAC mono a 44,1 kHz y faststart.
El audio completo aportado se conserva; no se añade música, voz ni efectos.
No se añaden subtítulos, logotipos ni rótulos. Se emplean cortes y zooms
centrados de hasta un 2 %. La imagen final cubre el cierre del audio.

## Reproducir

Requisitos: Python 3, FFmpeg y FFprobe con libx264 y AAC.

Descomprime el ZIP de edición y ejecuta:

```bash
python montar.py --fuentes /ruta/kaise-Documental --salida /ruta/exportacion
```

La carpeta de fuentes debe contener los originales `1.jpg` a `30.jpg`
y el audio `.mpeg` del repositorio. El script no cambia esos archivos.
El ZIP no duplica las fuentes, que se encuentran en el repositorio.
`fuentes_sha256.json` registra sus hashes.

El script vuelve a exportar y comprueba el formato, los fotogramas,
la duración del audio y la decodificación completa. Puede reutilizar
segmentos con dimensiones, formato y número de fotogramas válidos;
si cambias una imagen, elimina primero su segmento para regenerarlo.

## Sincronización

`marcas_tiempo.csv` contiene los límites reales cuantizados a 30 fps,
el número de escena, el archivo original y la frase de referencia.
`transcripcion.json` contiene palabras y marcas temporales obtenidas
con faster-whisper small en español. `transcripcion.txt` es su versión legible.
La transcripción automática puede contener errores ortográficos en nombres
propios; estos no se incorporan como texto ni como audio al montaje.

No se dividió el audio en intervalos iguales. El orden narrativo es
01–11, 13, 12 y 14–30. En las fuentes aportadas, `12.jpg` muestra
las camisetas (escena 13) y `13.jpg` la suscripción (escena 12).
La expulsión se muestra al pronunciar «expulsado», y el teléfono
apagado al llegar a «ni siquiera funcionaba».

## Validación y límites

`ffprobe_final.json`, `verificacion.json`, `sha256_final.txt` y
`contacto_video.jpg` documentan la comprobación técnica y visual.
Se analiza la decodificación completa, la correlación de la voz original
y exportada, su cierre, la ausencia de intervalos negros y faststart.
Se revisan visualmente muestras del video de las 30 escenas.
La revisión de sincronización se basa en la transcripción y sus palabras;
no se presenta como escucha humana completa.

Se mantienen las limitaciones de las ilustraciones recibidas:
`21.jpg` ya incluye el rótulo «ESCENA 21»; `23.jpg` muestra un teléfono
distinto, de aspecto moderno; la ropa del tramo del Bangu es amarilla y
verde. También varían algunos rasgos y objetos entre ilustraciones.
Estos elementos no fueron añadidos al editar. No se sustituyeron imágenes
ni se modificaron los archivos originales para ocultar esas diferencias.

Los archivos han sido generados en el entorno. La disponibilidad de una
descarga web depende de un destino autorizado; una ruta local por sí sola
no demuestra que un usuario pueda descargarlos en su computadora.
