import json
import subprocess
import numpy as np
from pathlib import Path
from faster_whisper import WhisperModel

root = Path('/workspace/kaise-Documental')
audio = next(root.glob('*.mpeg'))
model = WhisperModel('small', device='cpu', compute_type='int8', cpu_threads=4, download_root='/workspace/kaiser_models')
pcm = subprocess.check_output(['ffmpeg', '-v', 'error', '-i', str(audio), '-f', 'f32le', '-ac', '1', '-ar', '16000', '-'])
waveform = np.frombuffer(pcm, dtype=np.float32)
segments, info = model.transcribe(waveform, language='es', beam_size=5, word_timestamps=True, vad_filter=True)
rows = []
for s in segments:
    row = {'start': s.start, 'end': s.end, 'text': s.text, 'words': [{'start': w.start, 'end': w.end, 'word': w.word} for w in s.words]}
    rows.append(row)
    print(f'{s.start:.2f} - {s.end:.2f}: {s.text}', flush=True)
Path('/workspace/Kaiser_salida/transcripcion.json').write_text(json.dumps(rows, ensure_ascii=False, indent=2))
