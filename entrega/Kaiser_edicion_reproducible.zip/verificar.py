"""Comprobaciones sobre el archivo real exportado, no sobre el guion."""
import csv
import json
from pathlib import Path
import struct
import subprocess
import numpy as np

out = Path(__file__).resolve().parent
src = Path('/workspace/kaise-Documental')
video = out / 'Kaiser_documental_final.mp4'
rows = list(csv.DictReader((out / 'marcas_tiempo.csv').open(encoding='utf-8-sig')))

def decode(path):
    return np.frombuffer(subprocess.check_output(['ffmpeg', '-v', 'error', '-i', str(path), '-vn', '-ar', '16000', '-ac', '1', '-f', 'f32le', '-']), dtype=np.float32)

original = decode(next(src.glob('*.mpeg')))
final = decode(video)
n = min(len(original), len(final))
correlation = float(np.corrcoef(original[:n], final[:n])[0, 1])
tail = float(np.corrcoef(original[n-160000:n], final[n-160000:n])[0, 1])
assert correlation > 0.99 and tail > 0.99
assert len(final) >= len(original) - 32
black = subprocess.run(['ffmpeg', '-hide_banner', '-i', str(video), '-vf', 'blackdetect=d=0.05:pix_th=0.10:pic_th=0.99', '-an', '-f', 'null', '-'], capture_output=True, text=True, check=True)
black_events = [line for line in black.stderr.splitlines() if 'black_start:' in line]
assert not black_events, black_events
atoms = []
with video.open('rb') as f:
    while header := f.read(8):
        size, name = struct.unpack('>I4s', header)
        consumed = 8
        if size == 1:
            size = struct.unpack('>Q', f.read(8))[0]
            consumed = 16
        atoms.append(name.decode('ascii'))
        if size == 0:
            break
        f.seek(size-consumed, 1)
assert atoms.index('moov') < atoms.index('mdat')
midframes = [(int(r['fotograma_inicio']) + int(r['fotograma_fin_exclusivo']) - 1)//2 for r in rows]
select = '+'.join(f'eq(n,{n})' for n in midframes)
subprocess.run(['ffmpeg', '-hide_banner', '-loglevel', 'error', '-y', '-threads', '4', '-i', str(video), '-vf', f"select='{select}',scale=320:180,tile=5x6", '-frames:v', '1', str(out / 'contacto_video.jpg')], check=True)
report = {
    'escenas': len(rows),
    'orden_escenas': [r['escena'] for r in rows],
    'correlacion_audio_completo': correlation,
    'correlacion_ultimos_10_segundos': tail,
    'duracion_audio_original_decodificado': len(original)/16000,
    'duracion_audio_final_decodificado': len(final)/16000,
    'intervalos_negros_detectados': black_events,
    'faststart_moov_antes_de_mdat': True,
    'audio_anadido': False,
    'subtitulos_anadidos': False,
    'base_temporal': 'Transcripción automática con palabras y revisión de puntos de corte; cuantización hacia el siguiente fotograma a 30 fps.',
    'limites': [
        'La sincronización fue revisada con la transcripción y sus marcas de palabra; no se afirma una revisión auditiva humana.',
        'Se conservan las ilustraciones aportadas: 21.jpg ya contiene el rótulo ESCENA 21; no se añadieron rótulos al video.',
        'El teléfono de 23.jpg difiere del de 21.jpg; la indumentaria aportada para el relato de Bangu es amarilla y verde.',
        'Las fuentes permanecen intactas; no se generaron imágenes de reemplazo.'
    ]
}
(out / 'verificacion.json').write_text(json.dumps(report, ensure_ascii=False, indent=2))
print(json.dumps(report, ensure_ascii=False, indent=2))
