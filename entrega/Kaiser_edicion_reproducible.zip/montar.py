"""Montaje reproducible: Python 3 + FFmpeg/FFprobe; no modifica las fuentes.

Uso: python montar.py --fuentes /ruta/kaise-Documental --salida /ruta/exportacion
Necesita marcas_tiempo.csv junto a este script, derivado de la voz real.
"""
import argparse
import csv
import hashlib
import json
import math
from pathlib import Path
import subprocess


def run(args):
    subprocess.run(args, check=True)


def probe(path):
    return json.loads(subprocess.check_output(['ffprobe', '-v', 'error', '-show_format', '-show_streams', '-of', 'json', str(path)]))


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--fuentes', type=Path, required=True)
    p.add_argument('--salida', type=Path, required=True)
    args = p.parse_args()
    src, out = args.fuentes.resolve(), args.salida.resolve()
    out.mkdir(parents=True, exist_ok=True)
    audio_files = list(src.glob('*.mpeg'))
    if len(audio_files) != 1:
        raise ValueError('Se requiere exactamente un audio .mpeg de las fuentes originales')
    audio = audio_files[0]
    duration = float(probe(audio)['format']['duration'])
    rows = list(csv.DictReader((Path(__file__).parent / 'marcas_tiempo.csv').open(encoding='utf-8-sig')))
    expected = list(range(1, 12)) + [13, 12] + list(range(14, 31))
    assert [int(r['escena']) for r in rows] == expected
    assert len(rows) == 30
    assert all((src / r['archivo_original']).is_file() for r in rows)
    boundaries = [int(r['fotograma_inicio']) for r in rows]
    assert boundaries[0] == 0
    assert all(b > a for a, b in zip(boundaries, boundaries[1:]))
    total_frames = math.ceil(duration * 30)
    ends = boundaries[1:] + [total_frames]
    segments = out / 'segmentos'
    segments.mkdir(exist_ok=True)
    for i, (row, start, end) in enumerate(zip(rows, boundaries, ends)):
        n = end - start
        clip = segments / f'{i+1:02d}_escena_{int(row["escena"]):02d}.mp4'
        if clip.exists():
            info = probe(clip)['streams'][0]
            if int(info.get('nb_frames', -1)) == n and info['width'] == 1920 and info['height'] == 1080 and info['pix_fmt'] == 'yuv420p' and info.get('color_range') == 'tv':
                print(f'Reutilizando segmento comprobado: {clip.name}', flush=True)
                continue
        # Zoom discreto <= 2%; caras y objetos centrales permanecen en márgenes seguros.
        z = f'1+0.02*on/{max(1,n-1)}' if i % 2 == 0 else f'1.02-0.02*on/{max(1,n-1)}'
        vf = ("scale=3840:2160:force_original_aspect_ratio=decrease,"
              "pad=3840:2160:(ow-iw)/2:(oh-ih)/2:color=black,setsar=1,"
              f"zoompan=z='{z}':x='iw/2-iw/zoom/2':y='ih/2-ih/zoom/2':d={n}:s=1920x1080:fps=30,"
              "scale=in_range=full:out_range=tv:in_color_matrix=bt601:out_color_matrix=bt709,"
              "format=yuv420p,setparams=range=limited:color_primaries=bt709:color_trc=bt709:colorspace=bt709")
        run(['ffmpeg', '-hide_banner', '-loglevel', 'error', '-y', '-filter_threads', '2',
             '-i', str(src / row['archivo_original']), '-vf', vf, '-frames:v', str(n),
             '-an', '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '18', '-threads', '4',
             '-r', '30', '-pix_fmt', 'yuv420p', '-color_range', 'tv', '-colorspace', 'bt709',
             '-color_primaries', 'bt709', '-color_trc', 'bt709', '-video_track_timescale', '15360', str(clip)])
        print(f'Completado {i+1}/30: escena {row["escena"]}, {n} fotogramas', flush=True)
    concat = out / 'segmentos.txt'
    concat.write_text(''.join(f"file 'segmentos/{i+1:02d}_escena_{int(row['escena']):02d}.mp4'\n" for i, row in enumerate(rows)))
    final = out / 'Kaiser_documental_final.mp4'
    # Sin -shortest ni -t: conserva la totalidad del audio. La imagen final
    # termina en el primer límite de fotograma posterior al final de la voz.
    run(['ffmpeg', '-hide_banner', '-loglevel', 'error', '-y', '-f', 'concat', '-safe', '0',
         '-i', str(concat), '-i', str(audio), '-map', '0:v:0', '-map', '1:a:0',
         '-c:v', 'copy', '-c:a', 'aac', '-b:a', '192k', '-movflags', '+faststart',
         '-map_metadata', '-1', '-metadata', 'title=Carlos Kaiser', str(final)])
    meta = probe(final)
    (out / 'ffprobe_final.json').write_text(json.dumps(meta, indent=2))
    v = next(s for s in meta['streams'] if s['codec_type'] == 'video')
    a = next(s for s in meta['streams'] if s['codec_type'] == 'audio')
    assert (v['width'], v['height'], v['pix_fmt'], v['codec_name'], v['r_frame_rate']) == (1920, 1080, 'yuv420p', 'h264', '30/1')
    assert a['codec_name'] == 'aac'
    assert int(v['nb_frames']) == total_frames
    assert abs(float(a['duration']) - duration) < 0.1
    run(['ffmpeg', '-v', 'error', '-i', str(final), '-f', 'null', '-'])
    (out / 'sha256_final.txt').write_text(hashlib.sha256(final.read_bytes()).hexdigest() + '  ' + final.name + '\n')
    print(f'Exportación y decodificación completas: {final}', flush=True)


if __name__ == '__main__':
    main()
